from cs1lib import *
from driverforcities import*


img = load_image("world.png")
img2= load_image("pin.png")
#world_cities=open("cities_out.txt","r")
citynumber=50
drawing=True
i=0

sort(list, compare_population)

#creating empty lists for logitude and latitude
list_longitude=[]
list_latitude=[]

cities_population = open("cities_population.txt", "r")

def visualize():
    global drawing, citycount
    if drawing:

        draw_image(img, 0, 0)
        drawing=False

def draw_cities():
    global drawing, citycount, i

    #for anycity in range(citynumber):
        #list_longitude.append(float(list[anycity].longitude*2+360))
        #list_latitude.append(float(list[anycity].latitude*-2+180))

# for anycity in range(citynumber):
# list_longitude.append(float(list[anycity].longitude*2+360))
# list_latitude.append(float(list[anycity].latitude*-2+180))
# I chose to switch out of the for loop because it took so much time to
# load my graph, but commented it out and left it in the file because
# I think it's useful for me in the future to come back to and see how i reasoned.

    if i < citynumber:
        city=list[i]
        x=int(360+city.longitude*2)
        y=int(180-city.latitude*2)
        enable_fill()
        set_fill_color(1,0,0)

        #draw_circle(x,y, city.population*0.0000005)
        draw_image(img2,x,y-10)

        #draw
        set_stroke_color(0,0,1)

        #writing text
        draw_text(str(city.name), x, y-10)
        i=i+1



#world_cities.close()
cities_population.close()


#The main function
def main():
    visualize()
    draw_cities()

#Starting graphics
start_graphics(main,height=360, width=720, framerate=1)