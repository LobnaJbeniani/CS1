#Lobna Jbeniani
#Feb 2020

from cs1lib import *
from driverforcities import*

#uploading the imagr
img = load_image("world.png")
#world_cities=open("cities_out.txt","r")

#defining the limit of cities we want to show on the map
citynumber=50
drawing=True
i=0

sort(list, compare_population)

#Creating empty Lists for the longitude and latitude

list_longitude=[]
list_latitude=[]

cities_population = open("cities_population.txt", "r")

#the visualize function
def visualize():
    global drawing, citycount
    if drawing:

        draw_image(img, 0, 0)
        drawing=False

#the draw cities function
def draw_cities():
    global drawing, citycount, i

    #for anycity in range(citynumber):
        #list_longitude.append(float(list[anycity].longitude*2+360))
        #list_latitude.append(float(list[anycity].latitude*-2+180))

#I chose to switch out of the for loop because it took so much time to
# load my graph, but commented it out and left it in the file because
# I think it's useful for me in the future to come back to and see how i reasoned.


    #In this case, I will be using an if statement
    if i < citynumber:
        city=list[i]
        #determining the x and y by conversion. They have to be floats
        x=float(360+city.longitude*2)
        y=float(180-city.latitude*2)

    #drawing the squares indicating the 50 most populous countries

        enable_fill()
        set_fill_color(1,0,0)
        disable_stroke()
        draw_rectangle(x,y, 6, 6)
        i=i+1



#world_cities.close()
cities_population.close()

def main():
    visualize()
    draw_cities()

#Starting Graphics
start_graphics(main,height=360, width=720, framerate=1)