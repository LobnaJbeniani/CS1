#Lobna Jbeniani
#Feb 2020
#CS1, Feb 24

from cs1lib import *
from city import City
from Jbeniani_sort_cities import *
in_file = open("world_cities.txt", "r")

#Here we're creating an empty list into which we will be appending the list of lines
list=[]

for line in in_file:
    stripped_line=line.strip()
    clauses=stripped_line.split(",")
    city = City(clauses[0], clauses[1], clauses[2], clauses[3], clauses[4], clauses[5])
    list.append(city)


#Opening the cities_out file and writing into it

out_file=open("cities_out.txt","w")
for i in list:
    out_file.write(str(i)+"\n")
out_file.close()


#What we want next to loop through the cities in the in_file in order
# to organize them all alphabetically
#No that we have the cities in the list
cities_alpha=open("cities_alpha.txt", "w")
def alphabetize(city2,city1):
    return city1.name.upper()>=city2.name.upper()

#Calling the sort function in order to organize the list of countries in an alphabetical order
sort(list,alphabetize)


#writing into the new file
for j in list:
    cities_alpha.write(str(j)+"\n")
cities_alpha.close()


#Opening a new file and defining a function that will sort based on population
#in each city
cities_population=open("cities_population.txt","w")
def compare_population(city2,city1):
        return city2.population>=city1.population

sort(list, compare_population)

#writing into the new file
for j in list:
    cities_population.write(str(j)+"\n")
cities_population.close()




#Opening a new file and determining the function that will sort the cities
#based on latitudes
cities_latitude=open("cities_latitudes.txt","w")
def compare_latitudes(city2,city1):
        return city1.latitude>=city2.latitude
sort(list, compare_latitudes)


#wiriting into the new file
for j in list:
    cities_latitude.write(str(j)+"\n")

cities_latitude.close()
in_file.close()