#Lobna Jbeniani
#Feb 2020
#quicksortfile


#This function compares any two variables a and b
def compare_func(a ,b):
    return a<= b


#Partition allows us to organize the list around the pivot, with the larger values to its right and smaller to its left
def partition(the_list, p, r, compare_func):
    i = p - 1
    j = p
    pivot = the_list[r]

    for j in range(p,r):
        #print(the_list)

        if compare_func(the_list[j], pivot)==False:
            j += 1

        elif compare_func(the_list[j], pivot):

            i += 1
            key = the_list[i]
            the_list[i] = the_list[j]
            the_list[j] = key
            j+= 1

    key=the_list[i+1]
    the_list[i+1]=the_list[r]
    the_list[r]= key

    return i+1
        #if the_list[i+1]==None:
            #the_list[r],the_list[r]=the_list[r],the_list[r]

#lista=[2, 8, 7, 1, 3, 5, 6, 4]
#partition(lista, 0, len(lista)-1, compare_func)
#print(lista)



#Quicksort Function
def quicksort(the_list, p=0, r=None, compare_func=compare_func):
    if r==None:
        r=len(the_list)-1
    # the base case
    if r-p < 1:
        return

    # the recursive case
    q = partition(the_list, p, r, compare_func)  # defining q
    quicksort(the_list, p, q-1, compare_func) #sorts everything to the left of q
    quicksort(the_list,q + 1, r, compare_func) #sorts everything to the right of q



#Sort Function: makes use of the quicksort in order to compare the different variables in the given files
def sort(the_list, compare_func):
    quicksort(the_list, 0, len(the_list)-1, compare_func)



