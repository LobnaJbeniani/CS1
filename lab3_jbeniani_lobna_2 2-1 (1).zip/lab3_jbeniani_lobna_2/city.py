#Lobna Jbeniani
#CS1, Feb 24, 2019

#Creating a class City
class City:
    def __init__(self, country_code, name, region, population, latitude, longitude):
        self.country_code=str(country_code)
        self.name=str(name)
        self.region=str(region)
        self.population=int(population)
        self.latitude=float(latitude)
        self.longitude=float(longitude)

#The method below ensures that when called upon we don;t get the address but str of whatever data we need
    def __str__(self):
        s=(self.name + "," + str(self.population)+ "," + str(self.latitude)+ "," + str(self.longitude))
        return s

#In here we're loading the image
    def map_markup(self):
        img = load_image("world.png")
        draw_image(img, 0, 0)
