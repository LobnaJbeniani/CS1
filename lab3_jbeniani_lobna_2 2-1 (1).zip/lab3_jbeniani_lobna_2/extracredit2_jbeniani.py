from cs1lib import *
from driverforcities import*

#uploading the two images

img = load_image("world.png")
img2= load_image("pin.png")


#world_cities=open("cities_out.txt","r")
citynumber=50
drawing=True
i=0

sort(list, compare_population)


list_longitude=[]
list_latitude=[]

#opening the cities population file
cities_population = open("cities_population.txt", "r")


#defining the visualization function
def visualize():
    global drawing, citycount
    if drawing:

        draw_image(img, 0, 0)
        drawing=False

#defining the draw_cities functions
def draw_cities():
    global drawing, citycount, i

    #for anycity in range(citynumber):
        #list_longitude.append(float(list[anycity].longitude*2+360))
        #list_latitude.append(float(list[anycity].latitude*-2+180))

    if i < citynumber:
        city=list[i]
        x=int(360+city.longitude*2)
        y=int(180-city.latitude*2)
        enable_fill()
        set_fill_color(0.9,0.5,0.5)
        disable_stroke()
        draw_circle(x,y, city.population*0.0000005)
        #draw_image(img2,x,y-10)
        #draw
        enable_stroke()
        set_stroke_color(0,0,1)
        set_font_bold()
        set_font_italic()
        draw_text(str(city.name), x, y-10)


        i=i+1



#world_cities.close()
cities_population.close()

#the main function which calls the previous two functions
def main():
    visualize()
    draw_cities()

#The start graphics
start_graphics(main,height=360, width=720, framerate=1)